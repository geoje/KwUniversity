#include <stdio.h>

int main(void) {
	int num;
	num = add(3, 8);
	printf("%d\n", num);

	return 0;
}