/*This source code copyrighted by Lazy Foo' Productions (2004-2015)
and may not be redistributed without written permission.*/

//Using SDL and standard IO
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>

//Screen dimension constants
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

const double TIMESTEP = 1/60.;
const double DOT_VEL = 20.;

SDL_Texture* loadTexture( const char* path, SDL_Renderer* renderer )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path, IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( renderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path, SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}

int main( int argc, char* args[] )
{
    //Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    //Create window
    SDL_Window* window = SDL_CreateWindow("Gyeongho Yang", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (window == NULL)
    {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    //Create renderer for window
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (renderer == NULL)
    {
        printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    SDL_Texture* texture = loadTexture("17-ball.png", renderer);
    if (texture == NULL)
    {
        printf("Failed to load texture image!\n");
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    int quit = 0;   //Main loop flag
    SDL_Event e;    //Event

    double posX = 0, posY = 0, velX = 0, velY = 0;

    SDL_Rect renderRect;
    renderRect.x = posX;
    renderRect.y = posY;
    renderRect.w = 50;
    renderRect.h = 50;

    //While application is running
    while( !quit )
    {
        //Handle events on queue
        while( SDL_PollEvent( &e ) != 0 )
        {
            //User requests quit
            if( e.type == SDL_QUIT )
            {
                quit = 1;
            }
			else if (e.type == SDL_KEYDOWN)
			{
				switch (e.key.keysym.sym)
				{
				case SDLK_UP: velY -= DOT_VEL; break;
				case SDLK_DOWN: velY += DOT_VEL; break;
				case SDLK_LEFT: velX -= DOT_VEL; break;
				case SDLK_RIGHT: velX += DOT_VEL; break;
				}
			}
			else if (e.type == SDL_MOUSEMOTION)
			{
				velX = 0;
				velY = 0;
				int x, y;
				SDL_GetMouseState(&x, &y);
				posX = x - renderRect.w / 2;
				posY = y - renderRect.h / 2;
			}

        }

		posX += velX*TIMESTEP;
		posY += velY*TIMESTEP;

		if (posX > SCREEN_WIDTH)
			posX = 0;
		else if (posX < 0)
			posX = SCREEN_WIDTH;

		if (posY > SCREEN_HEIGHT)
			posY = 0;
		else if (posY < 0)
			posY = SCREEN_HEIGHT;

		renderRect.x = posX;
		renderRect.y = posY;

        //Clear screen
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear( renderer );

        //Render texture to screen
        SDL_RenderCopy( renderer, texture, NULL, &renderRect );

        //Update screen
        SDL_RenderPresent( renderer );
    }

    //Destroy renderer
    SDL_DestroyRenderer(renderer);

    //Destroy window
    SDL_DestroyWindow( window );

    //Quit SDL subsystems
    SDL_Quit();

    return 0;
}