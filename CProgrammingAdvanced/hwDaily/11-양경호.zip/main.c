#include <stdio.h>
#include "func.h"

void main()
{
	int num;
	num = add(3, 8);
	printf("%d\n", num);

	system("PAUSE");
}