#pragma once
typedef struct
{
	double x;
	double y;
	double z;
} Point3D;
