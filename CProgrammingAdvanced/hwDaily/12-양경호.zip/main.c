#include <stdio.h>
#include "point.h"
#include "pointfunc.h"

void main()
{
	Point3D p1, p2;
	scanf_s("%lf %lf %lf %lf %lf %lf", &p1.x, &p1.y, &p1.z, &p2.x, &p2.y, &p2.z);
	printf("distance: %f\n", calcDist(p1, p2));
	system("PAUSE");
}