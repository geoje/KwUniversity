#pragma once

#include "point.h"
double calcDist(Point3D p1, Point3D p2);