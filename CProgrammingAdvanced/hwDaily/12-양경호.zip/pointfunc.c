#include <math.h>
#include "pointfunc.h"

double calcDist(Point3D p1, Point3D p2)
{
	double xdiff = p2.x - p1.x;
	double ydiff = p2.y - p1.y;
	double zdiff = p2.z - p1.z;
	return sqrt(xdiff*xdiff + ydiff*ydiff + zdiff*zdiff);
}